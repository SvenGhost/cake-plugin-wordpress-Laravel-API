<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Employee;
use Illuminate\Support\Facades\File;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employee = Employee::where('user_id', \Auth::user()->id)->get();
        return response()->json(
            [
                "data" => [
                    "data"    => $employee,
                ],
            ],
            200
        );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();
      
        //image upload
        if($image = $request->file('image')) {
            $destinationPath = 'uploads/';
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$profileImage";
        }

        $input['user_id'] = \Auth::user()->id;
        $employee = Employee::create($input);

        return response()->json(
            [
                "data" => [
                    "message" => "Success",
                    "data"    => $employee,
                ],
            ],
            200
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $employee = Employee::findOrFail($id);
        $user_id =  $employee->user_id ;
        if($user_id === \Auth::user()->id) {
            $employee->cake_name = $request->cake_name;
            $employee->type = $request->type;
            $employee->price = $request->price;
            $employee->recipe = $request->recipe;
        
            //image edit 
            if($request->hasfile('image')) {
                $destinationPath = 'uploads/'. $employee->image;
                //delete previous image 
                if(File::exists($destinationPath)) {
                    File::delete($destinationPath);
                }
                $file      = $request->file('image');
                $extension = $file->getClientOriginalExtension();
                $filename  = time(). '.' .$extension;
                $file->move('uploads/', $filename);
                $employee->image = $filename;
            }
            $employee->update();
            return response()->json(
                [
                    "data" => [
                        "message" => "Success",
                        "data"    => $employee,
                    ],
                ],
                200
            );
        }
        else {
            return response()->json(
                [
                    "data" => [
                        "message" => "Failed",
                        "data"    => "This User is not login"
                    ]
                ]
            );
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $employee = Employee::findOrFail($id);
        $user_id =  $employee->user_id ;
        if($user_id === \Auth::user()->id) {
            $employee->delete();
            return response()->json(
                [
                    "data" => [
                        "message" => "Success",
                        "data" => "deleted!",
                    ],
                ],
                200
            );
        } 
        else {
            return response()->json(
                [
                    "data" => [
                        "message" => "Failed",
                        "data"    => "This user is not login",
                    ]
                ]
            );
        }
    }
}
