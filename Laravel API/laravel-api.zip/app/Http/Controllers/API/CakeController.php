<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Cake;
use App\Models\Image;
use Illuminate\Support\Facades\File;

class CakeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cake = Cake::with('images')->where('user_id', \Auth::user()->id)->get();
        return response()->json(
            [
                "data" => [
                    "data"    => $cake,
                ],
            ],
            200
        );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

     public function store(Request $request) 
     {
        $request->validate([
            'cake_name' => 'required',
            'type'      => 'required',
            'price'     => 'required|numeric',
            'recipe'    => 'required',
        ]);
            
        $cake = new Cake([
            'cake_name' => $request->cake_name,
            'type'      => $request->type,
            'price'     => $request->price,
            'recipe'    => $request->recipe,
            'user_id'   => \Auth::user()->id,
        ]);
        $data = $cake->save();

        //multiple image upload
        if($request->hasFile('image')) 
        {
            $files = $request->file('image');
            foreach($files as $file) {
                $destinationPath = 'uploads/';
                $profileImage = uniqid().'_'.$file->getClientOriginalName();
                $file->move($destinationPath, $profileImage);
                $img = new Image;
                $img->cake_id = $cake->id;
                $img->image   = $profileImage;
                $data         = $img->save();
            }
        }
        return response()->json(
            [
                "data" => [
                    "message" => "Record Added successfully",
                    "data"    => $data,
                ],
            ],
            200
        );
     }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $cake    = Cake::with('images')->findOrFail($id);
        $user_id =  $cake->user_id ;
        if($user_id == \Auth::user()->id) {
            return response()->json(
                [
                    "data" => [
                        "data" => $cake,
                    ],
                ],
                200
            );
        } 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $cake = Cake::findOrFail($id);
        $user_id =  $cake->user_id ;
        if($user_id == \Auth::user()->id) {
            $data = $cake->update([
                'cake_name' => $request->cake_name,
                'type'      => $request->type,
                'price'     => $request->price,
                'recipe'    => $request->recipe,
            ]);
            if($request->hasFile('image')) 
            {
                $files = $request->file('image');
                foreach($files as $key => $file) {
                    $destinationPath = 'uploads/';
                    $profileImage    = uniqid().'_'.$file->getClientOriginalName();
                    $file->move($destinationPath, $profileImage);

                    if(array_key_exists($key, $request->image_ids)) {
                       
                        $img = Image::find($request->image_ids[$key]);
                        if(File::exists("uploads/".$img->image)) {
                            File::delete("uploads/".$img->image);
                        }
                        $img->cake_id = $cake->id;
                        $img->image   = $profileImage;
                        $data         = $img->save();
                    }
                    else {
                        $img = new Image;
                        $img->cake_id = $cake->id;
                        $img->image   = $profileImage;
                        $data = $img->save();
                    }
                }
            }
            return response()->json(
                [
                    "data" => [
                        "message" => "Record Updated successfully",
                        "data"    => $data,
                    ],
                ],
                200
            );
        }
        else {
            return response()->json(
                [
                    "data" => [
                        "message" => "Failed",
                        "data"    => "This User is not login"
                    ]
                ]
            );
        }
    }

   
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

     public function destroy($id)
     {
        $cake = Cake::findOrFail($id);
        $user_id =  $cake->user_id ;
        if($user_id == \Auth::user()->id) {
            $images = Image::where("cake_id", $cake->id)->get();
            foreach($images as $image) {
                if(File::exists("uploads/".$image->image)) {
                    File::delete("uploads/".$image->image);
                }
                $image->delete();
            }
            $cake->delete();
            return response()->json(
                [
                    "data" => [
                        "message" => "Record Deleted Successfully",
                        "data"    => $cake,
                    ],
                ],
                200
            );
        } 
        else {
            return response()->json(
                [
                    "data" => [
                        "message" => "Failed",
                        "data"    => "This user is not login",
                    ]
                ]
            );
        }
     }

    //filter by type
    public function searchResult(Request $request)
    {
        $type = $request->type;
        $data = Cake::with('images')->where('type', '=', $type)->get();
        return response()->json(
            [
                "data" => $data,
            ]
        );
    }
    
}
