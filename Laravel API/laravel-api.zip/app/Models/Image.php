<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Cake;

class Image extends Model
{
    use HasFactory;
    protected $fillable = [
        'image',
        'cake_id',
    ];

    public function cakes() {
        return $this->belonsTo(Cake::class);
    }
}
