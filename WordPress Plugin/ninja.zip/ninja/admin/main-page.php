<?php

add_action('admin_menu', 'ninja_plugin_setup_menu');
 
function ninja_plugin_setup_menu(){
    add_menu_page( __( 'Add Ninja Cake', 'ninja' ), __( 'Ninja Cake', 'ninja' ), 'manage_options', 'ninja-plugin', 'ninja_admin_page' );
}
 
function ninja_admin_page(){
    ?>
    <div class="wrap">
    
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

        <form method="post" action="#" id="ninja_add_cake_form">
            <table class="form-table" role="presentation">
                <tbody>
                    <tr>
                        <th scope="row"><label for="c_name"><?php _e( 'Cake Name', 'ninja' );?></label></th>
                        <td><input name="cake_name" type="text" id="c_name" class="regular-text" placeholder="Type cake name here."></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="c_images"><?php _e( 'Cake Images', 'ninja' );?></label></th>
                        <td><input name="image[]" type="file" id="c_images" class="" multiple></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e( 'Cake Type', 'ninja' );?></th>
                        <td>
                            <fieldset>
                                <legend class="screen-reader-text"><span><?php _e( 'Cake Type', 'ninja' );?></span></legend>
                                <label><input type="radio" name="type" value="Sugar Free"> <span class="date-time-text format-i18n"><?php _e( 'Sugar Free', 'ninja' );?></span></label><br>
                                <label><input type="radio" name="type" value="Brownie"> <span class="date-time-text format-i18n"><?php _e( 'Brownie', 'ninja' );?></span></label><br>
                                <label><input type="radio" name="type" value="Cupcakes"> <span class="date-time-text format-i18n"><?php _e( 'Cupcakes', 'ninja' );?></span></label><br>
                                <label><input type="radio" name="type" value="Chocolate strip"> <span class="date-time-text format-i18n"><?php _e( 'Chocolate strip', 'ninja' );?></span></label><br>
                            </fieldset>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="c_receipe"><?php _e( 'Cake Receipe', 'ninja' );?></label></th>
                        <td><textarea name="recipe" rows="8" cols="50" id="c_receipe" class="code"></textarea></td>
                    </tr>
                                        <tr>
                        <th scope="row"><label for="c_name"><?php _e( 'Price', 'ninja' );?></label></th>
                        <td><input name="price" type="text" id="price" class="regular-text" placeholder="Price"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="c_receipe">&nbsp;</label></th>
                        <td>
                            <p class="submit"><input type="submit" name="submit_cake" id="submit_cake" class="button button-primary" value="Add Cake"></p><br>
                            <div id="ninja_add_success"></div>
                        </td>
                    </tr>


                </tbody>
            </table>
        </form>
    </div>
    <?php
}