

jQuery(document).ready(function () { 
    jQuery('body').on('click', '#submit_cake', function(){

        var btn = jQuery(this);
        btn.prop('disabled', true);

        var form = new FormData(jQuery('#ninja_add_cake_form')[0]);

        jQuery.ajax({
            url: NINJA.API_URL+'cake',
            type: 'POST',
            xhr: function() {
                var myXhr = jQuery.ajaxSettings.xhr();
                return myXhr;
            },
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', NINJA.API_TOKEN);
            },
            success: function (res) {
                jQuery('#ninja_add_success').html('Cake Added successfully');
                btn.prop('disabled', false);
            },
            error: function (err) {
                jQuery('#ninja_add_success').html('Something went wrong');
                btn.prop('disabled', false);
            },
            data: form,
            cache: false,
            contentType: false,
            processData: false
        });
    });
}); 

