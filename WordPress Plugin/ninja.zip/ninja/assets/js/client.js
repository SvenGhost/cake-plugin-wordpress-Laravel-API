
jQuery(document).ready(function () { 

    if(jQuery('#ninja_cake_list').length > 0){

        if(jQuery('#ninja_cake_list').data('cat') !=''){
            var c_data = {type: jQuery('#ninja_cake_list').data('cat')};
        }else{
            var c_data = {};
        }

        jQuery.ajax({
            url: NINJA.API_URL+'cake',
            type: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', NINJA.API_TOKEN);
            },
            data: c_data,
            success: function (res) {

                let parent_url = jQuery('#ninja_cake_list').data('url');

                jQuery.each(res.data.data, function(index, element) {

                    let c_img = (element.images[0] && element.images[0]['image']) ? element.images[0]['image'] : '';
    
                    jQuery('#ninja_cake_list').append('<div class="col-md-3"><div class="item"><div class="item-img"> <img class="img-1" src="'+c_img+'" alt=""></div><div class="item-name"> <a href="'+parent_url+'?cakeid='+element.id+'">'+element.cake_name+'</a><p>'+element.recipe+'</p></div><span class="price"><small>Type</small>'+element.type+'</span><div class = "purchase-info"><button type = "button" class = "btn">Add to Cart <i class = "fas fa-shopping-cart"></i></button></div></div></div>');
                });
             },
            error: function () { },
        });


    }

}); 



jQuery(document).ready(function () { 

    if(jQuery('#cake_detail_block').length > 0){


        var c_id = jQuery('#cake_detail_block').data('cid');

        jQuery.ajax({
            url: NINJA.API_URL+'show/'+c_id,
            type: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', NINJA.API_TOKEN);
            },
            data: {},
            success: function (res) {

                var ele = res.data.data;

                jQuery.each(ele.images, function(index, ig) {
                    jQuery('#cake_imgs').append('<img src = "'+ig.image+'" alt = "shoe image">');
                    jQuery('#cake_thumbs').append('<div class = "img-item"><a href = "#" data-id = "'+index+'"><img src = "'+ig.image+'" alt = "shoe image"></a></div>');
                });

                jQuery('#cake_title').html(ele.cake_name);
                jQuery('#cake_type').html(ele.type);
                jQuery('#cake_receipe').html(ele.recipe);
                jQuery('#cake_price').html(ele.price);


             },
            error: function () { },
        });

    }

}); 